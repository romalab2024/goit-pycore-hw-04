from datetime import datetime

def get_days_from_today(date: str) -> int:
    try:
        # Перетворюємо рядок дати у форматі 'РРРР-ММ-ДД' в об'єкт datetime
        given_date = datetime.strptime(date, '%Y-%m-%d').date()

        # Отримуємо поточну дату без часу
        today = datetime.today().date()

        # Розраховуємо різницю між поточною датою та заданою датою
        delta = today - given_date
        
        # Повертаємо різницю в днях
        return delta.days
    except ValueError:
        # Якщо формат дати некоректний, виводимо помилку
        return "Неправильний формат дати. Використовуйте формат 'РРРР-ММ-ДД'."

# Приклад використання функції
example_date = "2020-10-09"
result = get_days_from_today(example_date)
print(result)
